#define EXERC1

#include <cstdlib>
#include <iostream>

using namespace std;
            
#if defined(EXERC1)
// QUESTÃO 1: Critique o código abaixo e aponte seus problemas com relação:
//          a) à flexibilidade da implementação: alterações em pequenos trechos 
//             do código não deveriam exigir recodificação de outras partes

//          r: O código fica pouco flexível por ter somente um construtor, e 
//             também não tem nenhum destrutor para a classe Casa. Também falta
//             o get e set do atributo a.

//          b) à legibilidade do código: lendo o código é fácil entender os 
//             objetos e processos que ele representa. Qual é seu objetivo?

//          r: O código não consegue ser tão legível pela falta de clareza no nome
//             dos atributos, não possibilitando o entendimento do que é cada coisa
//             dentro da classe. Além do código estar com uma identação não tão boa.
class Casa {
      float orc;
      int a;
public:
       Casa( float o ):orc(o){ cout << "Casa criada..." << endl; }
       void setOrc( float o ) { orc = o; }
       float getOrc( void ) { return orc; }
};

#else
// QUESTAO 2: Corrija os problemas identificado na quest�o 1.
class Casa {
      // Coloque suas corre��es aqui...
      // aqui, assumirei que 'orc' será 'orcamento'
      float orcamento;
      // por não fazer ideia alguma do que se trata o atributo 'a', irei retirá-lo

      public: 

      Casa () : orcamento (0){
            cout << "Casa criada" << endl;
      } // Construtor vazio

      Casa (float orcamento) : orcamento (orcamento){
            cout << "Casa criada" << endl;
      }

      ~Casa(){}; // Destrutor

      // Get e Set
      
      void setOrcamento(float orcamento){
            this->orcamento = orcamento;
      }
      float getOrcamento(){
            return orcamento;
      }
};
// ...e aqui se necess�rio.
#endif

// QUESTAO 3: Explique o c�digo abaixo e cada uma das linhas de texto que 
// formam sua sa�da.


int main(int argc, char *argv[])
{
    Casa c1(7), *c2 = &c1, &c3 = c1;
    // O objeto C1 é criado recebendo o valor 7 para orc

    // C2 é criado como um ponteiro, e ele recebe o endereço de C1, assim, tudo o que ocorrer em C1,
    // também irá ocorrer em C2

    // C3 também receberá uma referencia a C1, então, novamente, o que acontece em C1, 
    // também irá ocorrer em C3

    cout << "C1: " << c1.getOrc() << endl;
    // Nessa linha será impresso o valor 7
    c1.setOrc(3);
    // aqui, o valor de orc em C1 é mudado para 3, mudando também os valores em C2 e C3
    cout << "C2: " << c2->getOrc() << ", ";
    // Aqui será impresso o valor 3
    cout << "C3: " << c3.getOrc() << endl;
    // e aqui também
    cout << "C2: " << c2 << ", C3: " << &c3 << endl;
    // aqui será impresso os endereços de C2 e C3

    system("PAUSE");
    return EXIT_SUCCESS;
}
// QUESTAO 4: Quantas vezes o construtor da classe foi invocado? Por que?

// r: O destrutor será chamado uma única vez, pois C2 e C3 são referências a C1, e quando o destrutor
//    é chamado pra C1, irá apagar junto C2 e C3.
