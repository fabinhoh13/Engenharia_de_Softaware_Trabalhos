#include <cstdlib>
#include <iostream>

using namespace std;
            
// QUEST�O 1: O c�digo desse exerc�cio � id�ntico ao do exerc�cio anterior. 
//          Por�m o operador "<<" foi sobrecarregado para permitir que 
//          programador implemente de maneira mais f�cil a sa�da do programa.
//          Desta maneira, o codigo a seguir pode ser utilizado para imprimir
//          na tela um objeto "Casa": Casa c1; cout << c1; 
//
//          a) Explique porque o m�todo que sobrecarrega o operador "<<" precisou
//          ser declarado como amigo ("friend") da classe Casa? 
//          r: Para que o método sobrecarregado possa acessar os atributos privados
//             da classe.

//          b) Explique o funcionamento do novo operador "<<".
//          r: O novo operador "<<" quando chamado dentro do cout, imprime os dados da classe, no caso
//             o valor de orc
class Casa {
      float orc;
public:
		// Casa( float o ):orc(o){ printf("Casa criada..."); }
       Casa( float o ):orc(o){ cout << "Casa criada..." << endl; }
       void setOrc( float o ) { orc = o; }
       float getOrc( void ) { return orc; }
       friend ostream& operator<<( ostream& s, Casa& c) {  s << c.orc; return s; }
};

// QUEST�O 2: Explique o c�digo abaixo e cada uma das linhas de texto que 
// formam sua sa�da.
int main(int argc, char *argv[])
{
    Casa c1(7), &c2 = c1;
    // Aqui é criado um objeto C1 do tipo Casa, onde o valor do atributo orc recebe o valor 7

    // Além disso, é criado também um objeto C2, também do tipo Casa, porém ele recebe uma referencia a C1
    cout << "C1: " << c1.getOrc() << ", C2: " << c2.getOrc() << endl;
    // Nessa linha os valores são impressos a partir do uso do getter
    c2.setOrc(3);
    // O valor de orc em C2 é trocado para 7, Dessa forma, o valor em C1 também muda
    cout << "C1: " << c1 << ", C2: " << c2 << endl;
    // Aqui é impresso os valores a partir da sobrecarga
    
    system("PAUSE");
    return EXIT_SUCCESS;
}

