#ifndef VENDAS_H
#define VENDAS_H

#include <QDialog>
#include <string>
#include <vector>
#include <iostream>

using namespace std;

#include "veiculos.h"
namespace Ui {
class vendas;
}

class vendas : public QDialog
{
    Q_OBJECT

public:
    explicit vendas(QWidget *parent = nullptr);
    ~vendas();

private slots:
    void on_pushButtonBack_clicked();

    void on_pushButtonSold_clicked();

private:
    Ui::vendas *ui;

    vector <veiculos> veiculosVendidos;
};

#endif // VENDAS_H
