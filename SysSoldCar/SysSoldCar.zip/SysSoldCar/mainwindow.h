#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <vector>

#include "vendas.h"
#include "telavendedores.h"
#include "funcionarios.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_clicked();

    void on_pushButtonVendedores_clicked();

private:
    Ui::MainWindow *ui;
    vendas *v;
    telaVendedores *tv;

    std :: vector <funcionarios> todosFuncionarios;
};
#endif // MAINWINDOW_H
