#include "veiculos.h"

vector <veiculos> veiculos :: vVeiculos;

veiculos :: veiculos() {}
veiculos :: ~veiculos() {}
veiculos :: veiculos (string veiculo, string prop, int valor, string placa, string renavam) :
    veiculo (veiculo), proprietario (prop), valor (valor), placa (placa), renavam (renavam) {}


void veiculos :: addVeiculos (veiculos novo) {
    vVeiculos.push_back(novo);
}

void veiculos :: saida (ostream & out) const {
    out << veiculo << endl;
}

ostream& operator<<(ostream &out, const veiculos &obj) {
    obj.saida(out);
    return out;
}
