#include "telavendedores.h"
#include "ui_telavendedores.h"

telaVendedores::telaVendedores(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::telaVendedores)
{
    ui->setupUi(this);
    vFuncionarios = funcionarios::criarFuncionariosTeste();
}

telaVendedores::~telaVendedores()
{
    delete ui;
}

void telaVendedores::on_pushButtonBack_clicked()
{
    close();
    this->parentWidget()->show();
}

void telaVendedores :: addFuncioario (funcionarios novo) {
    vFuncionarios.push_back(novo);
}

void telaVendedores::on_pushButtonAdd_clicked()
{
    ad = new addVendedor (this);
    ad->show();
    //hide();
}

