#include "funcionarios.h"

vector <funcionarios> funcionarios :: vVendedores;

funcionarios :: funcionarios() {}
funcionarios :: ~funcionarios() {}
funcionarios :: funcionarios(string nome, string cpf, string dn, int salario, string sexo, string end):
    nome (nome), cpf(cpf), dataNascimento (dn), salario (salario), sexo (sexo), endereco (end){}



vector <funcionarios> funcionarios :: criarFuncionariosTeste () {
    vector <funcionarios> f;
    funcionarios novo ("Fabio Fernandes", "111.111.111-11", "18/03/2000", 1500, "M", "Rua dos Bobos, Nro 0, Bairro Boca, BILI-BL");
    f.push_back(novo);
    funcionarios novo1 ("Gabriel Fernandes", "222.222.222-22", "12/06/2001", 2100, "M", "Rua dos Cria, Nro 10, Bairro Casa, CAAL-BR");
    f.push_back(novo1);

    return f;
}

void funcionarios :: criarFuncionariosParaTeste() {
    funcionarios novo ("Fabio Fernandes", "111.111.111-11", "18/03/2000", 1500, "M", "Rua dos Bobos, Nro 0, Bairro Boca, BILI-BL");
    vVendedores.push_back(novo);
    funcionarios novo1 ("Gabriel Fernandes", "222.222.222-22", "12/06/2001", 2100, "M", "Rua dos Cria, Nro 10, Bairro Casa, CAAL-BR");
    vVendedores.push_back(novo1);
}

void funcionarios :: addNovoVendedor (funcionarios novo){
    vVendedores.push_back(novo);
}

void funcionarios :: printVendedores () {
    for (auto i : vVendedores){
        cout << i.nome << endl;
    }
}
