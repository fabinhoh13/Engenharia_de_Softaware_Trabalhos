#include "login.h"
#include "ui_login.h"


#include <QMessageBox>

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
}

login::~login()
{
    delete ui;
}

void login::on_pushButton_clicked()
{
    QString nome = ui->lineEdit->text();
    QString senha = ui->lineEdit_2->text();

    if (nome == "admin" && senha == "admin"){
        hide();

        mw = new MainWindow (this);
        mw->show();
    }
    else {
        QMessageBox :: warning (this, "Login", "Username or/and password incorrect");
    }
}


void login::on_pushButton_released()
{

}


void login::on_pushButton_pressed()
{

}


