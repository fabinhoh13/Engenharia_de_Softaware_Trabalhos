
#ifndef TELAVENDEDORES_H
#define TELAVENDEDORES_H

#include <QDialog>
#include <vector>

#include "funcionarios.h"

#include "addvendedor.h"

using namespace std;

namespace Ui {
class telaVendedores;
}

class telaVendedores : public QDialog
{
    Q_OBJECT

public:
    explicit telaVendedores(QWidget *parent = nullptr);
    ~telaVendedores();
    void addFuncioario (funcionarios novo);

private slots:
    void on_pushButtonBack_clicked();

    void on_pushButtonAdd_clicked();

private:
    Ui::telaVendedores *ui;
    addVendedor *ad;

    vector <funcionarios> vFuncionarios;
};

#endif // TELAVENDEDORES_H
